var myApp=angular.module('myApp', ['ui.bootstrap']);

myApp.controller("CarouselCtrl",CarouselCtrl);

// Controller  for Carousel
function CarouselCtrl($scope,$http) {

// initializing the time Interval 
  $scope.myInterval = 5000;
  
        // Initializing  slide array    

         var url="http://localhost:8080/EventScheduler/getAllEventRegisterNews";
         $http.get(url).then(function(response){                        
                        $scope.mynews=response.data;  
                        });         
                             
  var mynews = $scope.mynews;

} 
