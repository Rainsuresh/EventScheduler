var myApp=angular.module("mymodule",[])

myApp.controller("mycontroller",function($scope){

var employee=[
	
{
name:"SivaSakthi",
dateofBirth:new Date("November 23,1980"),
gender:"Male",
salary:55000.788
},
{

name:"SeethaRam",
dateofBirth:new Date("May 05,1970"),
gender:"Male",
salary:68000
},
{
name:"ArthiSuresh",
dateofBirth:new Date("August 15,1974"),
gender:"Female",
salary:57000
},
{
name:"Pam",
dateofBirth:new Date("October 27,1979"),
gender:"Female",
salary:53000
},
{
name:"Todd",
dateofBirth:new Date("December 30,1983"),
gender:"Male",
salary:60000
}

];

$scope.employee=employee;
$scope.rowLimit=3;
$scope.sortColumn="salary";

});

