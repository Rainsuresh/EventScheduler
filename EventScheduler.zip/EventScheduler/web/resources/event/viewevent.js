var myApp=angular.module("mymodule",[]);


myApp.controller("EventController",EventController);

//EventController.$inject=['$http'];
//EventController.$injector=['$route'];



function EventController($http,$scope){
    var vm=this;
    vm.event=[];
    vm.getAll=getAll;    
    vm.getVal=getVal;    
    vm.deleteEvent=deleteEvent;    
    init();
    function init(){
        getAll();
        
    }
    function getAll(){
        
        
        var url="http://localhost:8080/EventScheduler/getAllEvent";
        $http.get(url).then(function(response){                        
                       vm.event=response.data;  
                       });         
    }
    function getVal(){
        console.log('hello');
        console.warn('hello world');
        
    }
    function deleteEvent($scope){
             
        var url="http://localhost:8080/EventScheduler/deleteevent/"+$scope.id;
        $http.get(url).then(function(response){                        
                       $scope.msg=response.data; 
                       
                        getAll();
                    });         
    }
    
}

