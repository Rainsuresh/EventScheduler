var myApp=angular.module("mymodule",[])

myApp.controller("UserController",UserController);

//EventController.$inject=['$http'];
//EventController.$injector=['$route'];



function UserController($http,$scope){
    var vm=this;
    vm.user=[];
    vm.getAll=getAll;    
    vm.getVal=getVal;    
    vm.deleteEvent=deleteEvent;    
    init();
    function init(){
        getAll();
        
    }
    function getAll(){
        
        
        var url="http://localhost:8080/EventScheduler/getAllUser";
        $http.get(url).then(function(response){                        
                       vm.user=response.data;  
                       });         
    }
    function getVal(){
        console.log('hello');
        console.warn('hello world');
        
    }
    function deleteEvent($scope){
             
        var url="http://localhost:8080/EventScheduler/deleteevent/"+$scope.id;
        $http.get(url).then(function(response){                        
                       $scope.msg=response.data; 
                       
                        getAll();
                    });         
    }
    
}

