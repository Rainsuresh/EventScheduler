'use strict';
 
var App = angular.module('myApp',['ui.bootstrap']);