angular.module('myApp', ['ui.bootstrap']);

// Controller  for Carousel
function CarouselCtrl($scope) {

// initializing the time Interval 
  $scope.myInterval = 5000;
     
 // Initializing  slide array   
$scope.slides = [
				
				{image:'/resources/slide/Hydrangeas.jpg',text:'Hydrangeas'},
                                {image:'/resources/slide/Desert.jpg',text:'Desert'},
  
                                {image:'/resources/slide/Chrysanthemum.jpg',text:'Chrysanthemum'},

                                {image:'/resources/slide/Penguins.jpg',text:'Penguins'}];

  var slides = $scope.slides;

} 
