'use strict';
 
angular.module('myApp').controller('EventRegisterController', ['$scope', 'EventRegisterService', function($scope, EventRegisterService) {
    var self = this;
    self.eventregister={p_id:null,c_id:'',paid_fees:'',paid_status:''};
    self.eventregisters=[];
 
    self.submit = submit;
    self.edit = edit;
    self.remove = remove;
    self.reset = reset;
    
        /*refresh*/
    self.refresh = refresh;
 
 
    fetchAllUsers();
 
    function fetchAllUsers(){
        EventRegisterService.fetchAllUsers()
            .then(
            function(d) {
                self.eventregisters = d;                                
            },
            function(errResponse){
                console.error('Error while fetching Users');
            }
        );
    }
    
    function refresh(){
    
            fetchAllUsers();
    }
 
    function createUser(eventregister){
        EventRegisterService.createUser(eventregister)
            .then(
            fetchAllUsers,
            function(errResponse){
                console.error('Error while creating User');
            }
        );
    }
 
    function updateUser(eventregister, id){
        EventRegisterService.updateUser(eventregister, id)
            .then(
            fetchAllUsers,
            function(errResponse){
                console.error('Error while updating User');
            }
        );
    }
 
    function deleteUser(id){
        EventRegisterService.deleteUser(id)
            .then(
            fetchAllUsers,
            function(errResponse){
                console.error('Error while deleting User');
            }
        );
    }
 
    function submit() {
        if(self.eventregister.id===null){
            console.log('Saving New User', self.eventregister);
            createUser(self.eventregister);
        }else{
            updateUser(self.eventregister, self.eventregister.id);
            console.log('User updated with id ', self.eventregister.id);
        }
        reset();
    }
 
    function edit(id){
        console.log('id to be edited', id);
        for(var i = 0; i < self.eventregisters.length; i++){
            if(self.eventregisters[i].id === id) {
                self.eventregister = angular.copy(self.eventregisters[i]);
                break;
            }
        }
    }
 
    function remove(id){
        console.log('id to be deleted', id);
        if(self.eventregister.id === id) {//clean form if the user to be deleted is shown there.
            reset();
        }
        deleteUser(id);
    }
 
 
    function reset(){
        self.eventregister={p_id:null,c_id:'',paid_fees:'',paid_status:''};
        $scope.myForm.$setPristine(); //reset Form
    }
 
}]);