var myApp=angular.module("myModule",[])

myApp.controller("mycontroller",function($scope){

var employee=[
{
firstName:"Siva",
lastName:"Sakthi",
gender:"Male"
},
{
firstName:"Seetha",
lastName:"Ram",
gender:"Male"
},
{
firstName:"Arthi",
lastName:"Suresh",
gender:"Male"
}
];
$scope.employee=employee;

});

