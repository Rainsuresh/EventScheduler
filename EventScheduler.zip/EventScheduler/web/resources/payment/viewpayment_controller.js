'use strict';
 
angular.module('myApp').controller('PaymentController', ['$scope', 'PaymentService', function($scope, PaymentService) {
    var self = this;
    self.payment={p_id:null,c_id:'',paid_fees:'',paid_status:''};
    self.payments=[];
 
    self.submit = submit;
    self.edit = edit;
    self.remove = remove;
    self.reset = reset;
    
        /*refresh*/
    self.refresh = refresh;
 
 
    fetchAllUsers();
 
    function fetchAllUsers(){
        PaymentService.fetchAllUsers()
            .then(
            function(d) {
                self.payments = d;                                
            },
            function(errResponse){
                console.error('Error while fetching Users');
            }
        );
    }
    
    function refresh(){
    
            fetchAllUsers();
    }
 
    function createUser(payment){
        PaymentService.createUser(payment)
            .then(
            fetchAllUsers,
            function(errResponse){
                console.error('Error while creating User');
            }
        );
    }
 
    function updateUser(payment, id){
        PaymentService.updateUser(payment, id)
            .then(
            fetchAllUsers,
            function(errResponse){
                console.error('Error while updating User');
            }
        );
    }
 
    function deleteUser(id){
        PaymentService.deleteUser(id)
            .then(
            fetchAllUsers,
            function(errResponse){
                console.error('Error while deleting User');
            }
        );
    }
 
    function submit() {
        if(self.payment.id===null){
            console.log('Saving New User', self.payment);
            createUser(self.payment);
        }else{
            updateUser(self.payment, self.payment.id);
            console.log('User updated with id ', self.payment.id);
        }
        reset();
    }
 
    function edit(id){
        console.log('id to be edited', id);
        for(var i = 0; i < self.payments.length; i++){
            if(self.users[i].id === id) {
                self.payment = angular.copy(self.payments[i]);
                break;
            }
        }
    }
 
    function remove(id){
        console.log('id to be deleted', id);
        if(self.payment.id === id) {//clean form if the user to be deleted is shown there.
            reset();
        }
        deleteUser(id);
    }
 
 
    function reset(){
        self.payment={p_id:null,c_id:'',paid_fees:'',paid_status:''};
        $scope.myForm.$setPristine(); //reset Form
    }
 
}]);