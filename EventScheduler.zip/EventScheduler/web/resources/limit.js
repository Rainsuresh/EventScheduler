var myApp=angular.module("mymodule",[])

myApp.controller("mycontroller",function($scope,$http){


 $http.get('http://localhost:8080/EventScheduler/getemployee')
                      .then(function(response){                        
                                  $scope.employee=response.data;  
                    }); 

});

