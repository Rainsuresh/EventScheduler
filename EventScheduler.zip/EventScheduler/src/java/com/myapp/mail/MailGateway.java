/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myapp.mail;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 *
 * @author Mayan
 */
public class MailGateway {
    String receiver;
    public String sendMail(String receiver){
        try{
    Resource r=new ClassPathResource("applicationContext.xml");  
    BeanFactory b=new XmlBeanFactory(r);  
    MailMail m=(MailMail)b.getBean("mailMail");  
    String sender="suresh.collage@gmail.com";//write here sender gmail id  
    this.receiver=receiver;//write here receiver id  
m.sendMail(sender,receiver,"Greeting from Sixface Technology","Welcome to Next Generation Payment");  
      
System.out.println("**************************successfully Mail Send************************************************"); 
            return "success";
        }catch(Exception e){
            return e.getMessage();
        }
    }
}
