
package com.myapp.controllers;

import com.myapp.beans.MessageRegister;
import com.myapp.beans.Event;
import com.myapp.dao.EventDao;
import java.util.ArrayList;  
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired; 

import java.security.Principal;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping(value = "/")
public class EventController {
    
    
    @Autowired
    EventDao dao1;//will inject dao1 from xml file    
      
     /*It displays a form to input data, here "command" is a reserved request attribute 
     *which is used to display object data into form 
     */ 
     @RequestMapping("/")  
    public ModelAndView index(){  
        return new ModelAndView("index");  
    }
    
     @RequestMapping("/eventform")  
    public ModelAndView showform(Principal p){  
        ModelAndView mvc=new ModelAndView();
        String name=p.getName();
        mvc.addObject("uname", name);
        mvc.addObject("command",new Event());
        
        return mvc;
    } 
   
    @RequestMapping("/eventdetail/{id}")  
    public ModelAndView eventdetail(@PathVariable int id){ 
        Event et=dao1.getEmpById(id);  
        return new ModelAndView("eventdetail","command",et);  
    }  
    
    
    
    /*It saves object into database. The @ModelAttribute puts request data 
     *  into model object. You need to mention RequestMethod.POST method  
     *  because default request is GET*/  
    @RequestMapping(value="/saveevent",method = RequestMethod.POST)  
    public ModelAndView save(@ModelAttribute("et") Event et){  
        dao1.save(et);
        return new ModelAndView("redirect:/viewevent");//will redirect to viewemp request mapping  
    }  
    /* It navigate viewevent */  
    @RequestMapping("/viewevent")  
    public ModelAndView viewevent(@ModelAttribute("m") MessageRegister m,Principal p){  
        
        ModelAndView mvc=new ModelAndView("viewevent");        
        String name=p.getName();
        mvc.addObject("uname", name);
        mvc.addObject("message", m.getMessage());
        return mvc;
        
    }  
    
    @RequestMapping(value = "/event/", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Event>> listAllEvents() {
        List<Event> users = dao1.getAllEvent();
        if(users.isEmpty()){
            return new ResponseEntity<List<Event>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<Event>>(users, HttpStatus.OK);
    }
    
    /* It displays object data into form for the given id.  
     * The @PathVariable puts URL data into variable.*/
    @RequestMapping(value="/editevent/{id}")  
    public ModelAndView edit(@PathVariable int id){  
        Event et=dao1.getEmpById(id);  
        return new ModelAndView("eventeditform","command",et);  
    }       
    
    /* It updates model object. */
    @RequestMapping(value="/editsaveevent",method = RequestMethod.POST)  
    public ModelAndView editsave(@ModelAttribute("et") Event et){  
        dao1.update(et);  
        return new ModelAndView("redirect:/viewevent");  
    }  
    /* It deletes record for the given id in URL and redirects to /viewemp */  
    @RequestMapping(value="/deleteevent/{id}",method = RequestMethod.GET)  
    public ModelAndView delete(@PathVariable int id){  
        ModelAndView mvc=new ModelAndView("redirect:/viewevent");
        try{
        dao1.delete(id);
        mvc.addObject("message", "Successfully Removed");
            return mvc;
        }catch(Exception e){
            mvc.addObject("message", "Failed to Remove record --> reason : "+e.getMessage());
            return mvc;
        }
          
    }     
}
