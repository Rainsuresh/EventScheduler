
package com.myapp.controllers;

import com.myapp.beans.MessageRegister;
import java.security.Principal;
import java.security.*;
import com.myapp.beans.Event;
import com.myapp.beans.EventRegister;
import com.myapp.beans.Payment;
import com.myapp.beans.PaymentEventRegister;
import com.myapp.beans.Register;
import com.myapp.dao.EventDao;
import com.myapp.dao.EventRegisterDao;
import com.myapp.dao.PaymentDao;
import com.myapp.dao.RegisterDao;
import com.myapp.mail.MailGateway;
import java.util.ArrayList;  
import java.util.List;  


import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import java.sql.SQLException;

@RestController
@RequestMapping(value = "/")
public class RegisterController {
        
    @Autowired
    RegisterDao dao2;//will inject dao2 from xml file    
      
    @Autowired            
    EventDao dao1;//will inject dao1 from xml file    
    
    @Autowired
    EventRegisterDao dao4;//will inject dao4 from xml file  
    
    @Autowired
    PaymentDao dao5;//will inject dao5 from xml file  
    
    @RequestMapping(value="/eventaccept",method = RequestMethod.POST)  
    public ModelAndView eventIdRegisterFormGet(@ModelAttribute("e") Event e){  
        
        ModelAndView mvc=new ModelAndView("candidate");
        mvc.addObject("e_id", e.getE_id());
        return mvc;
    }
    
    @RequestMapping(value="/formlogin/{e_id}")  
    public ModelAndView eventIdformlogin(@PathVariable int e_id){  
        
        ModelAndView mvc=new ModelAndView("formlogin");
        mvc.addObject("e_id", e_id);
        return mvc;
    }
    
    
     /*It displays a form to input data, here "command" is a reserved request attribute 
     *which is used to display object data into form 
     */  
    @RequestMapping("/candidateform")  
    public ModelAndView showform(){  
       // return new ModelAndView("candidateform","command",new Register());  
        return new ModelAndView("candidateform");  
    }  
       
    @RequestMapping("/mycandidate")  
    public ModelAndView mycandidate(){  
        return new ModelAndView("mycandidate","command",new Register());  
    }
        
    
    /*It saves object into database. The @ModelAttribute puts request data 
     *  into model object. You need to mention RequestMethod.POST method  
     *  because default request is GET*/  
    @RequestMapping(value="/savecandidate",method = RequestMethod.POST)  
    public ModelAndView save(@ModelAttribute("r") Register r,@ModelAttribute("er") EventRegister er){  
                ModelAndView mvc=new ModelAndView("login");
        try{                    
            
            int r2=dao2.getEmpEmail(r.getEmail()); //It checks 'email' is already exist in 'register table' or not.If exist return 1 otherwise return 0.
                                                  
                int cid=dao4.getEvtByEmailAndEventId(r.email, er.getE_id()); //It checks 'email','e_id' is already exist in 'event_register table' or not.If exist return 'candidate id' otherwise return 0.
                    System.out.println("cid "+r2);
                if(r2==0){                    
                        dao2.save(r);
                        dao4.save(er);
                        int cid1=dao4.getEvtByEmailAndEventId(r.email, er.getE_id());
                        dao5.savePayment(cid1, 0, "no");                                    
                        mvc.setViewName("login");
                }else{             
                    
                    mvc.addObject("e_id", r.getE_id());
                    mvc.addObject("mname", r.getName());
                    mvc.addObject("command",r);
                    mvc.setViewName("candidate");
                    /*if(cid==0){
                    dao4.save(er);
                    int cid1=dao4.getEvtByEmailAndEventId(r.email, er.getE_id());
                        System.out.println("Candidate Id : "+cid1);
                    dao5.savePayment(cid1, 0, "no");
                    }            
                    else{
                        System.out.println("No Action");
                    } */           
                }

        }catch(Exception e){
            System.err.println(e.fillInStackTrace());
        }
        
        /*
        
        MailGateway mailgate=new MailGateway();
        String msg=mailgate.sendMail(r.getEmail());
        System.out.println("++++++++++++++++++++++++Mail GateWay Called+++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++"+msg+"+++++++++++++++++++++++++++++");
        
        return new ModelAndView("redirect:/viewusers");//will redirect to viewemp request mapping  
        */
        
        //return new ModelAndView("payment","command",er);//will redirect to paymentform request mapping  
        return mvc;//will redirect to paymentform request mapping  
        
    }  
    
    @RequestMapping(value="/saveNext",method = RequestMethod.POST)  
    public ModelAndView saveNext(@ModelAttribute("r") Register r,@ModelAttribute("er") EventRegister er,Principal p){  
            ModelAndView mvc=new ModelAndView();            
        try{
            System.out.println("User Name : "+p.getName());
            System.out.println("++++++++++++++++++++++++++++++");  
            
            int r2=dao2.getEmpEmail(p.getName()); //It checks 'email' is already exist in 'register table' or not.If exist return 1 otherwise return 0.
                                   System.out.println("++++++++++++++++++++++++++++++");               
            int cid=dao4.getEvtByEmailAndEventId(p.getName(), r.getE_id()); //It checks 'email','e_id' is already exist in 'event_register table' or not.If exist return 'candidate id' return '1' otherwise return 0.

            System.out.println("Event id "+r.getE_id());
            System.out.println("cid "+cid);
            
            /*EventRegister er=new EventRegister();
            er.setE_id(r.getE_id());*/
            er.setEmail(p.getName());
            //System.out.println("++++++++++++++++++++++++++++++");     
            
            if(r2==1 &&cid==0){
                dao4.save(er);
                int cid1=dao4.getEvtByEmailAndEventId(p.getName(), r.getE_id());
                    System.out.println("Candidate Id : "+cid1);
                dao5.savePayment(cid1, 0, "no");
                mvc.addObject("message", "Successfully Registered for event "+r.getE_id());
                mvc.setViewName("redirect:/profile");
            }            
            else{
                System.out.println("No Action Performed!...");
                mvc.addObject("message", "You Are Already Register for that event: "+r.getE_id()+". If not please contact Admin!...");
                mvc.setViewName("redirect:/profile");
            }            
                

        }catch(Exception e){
            System.out.println("Error at point : "+e.getStackTrace());
            
            
        }
        
        /*
        
        MailGateway mailgate=new MailGateway();
        String msg=mailgate.sendMail(r.getEmail());
        System.out.println("++++++++++++++++++++++++Mail GateWay Called+++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++"+msg+"+++++++++++++++++++++++++++++");
        
        return new ModelAndView("redirect:/viewusers");//will redirect to viewemp request mapping  
        */
        
        //return new ModelAndView("payment","command",er);//will redirect to paymentform request mapping  
        return mvc;//will redirect to paymentform request mapping  
        
    }
    
    
    
    /* It provides list of employees in model object */  
    @RequestMapping("/viewusers")  
    public ModelAndView viewusers(Principal p){  
        List<Register> list=dao2.getAllUser();
         ModelAndView mvc=new ModelAndView();
        String name=p.getName();
        mvc.addObject("uname", name);
        mvc.addObject("list", list);
        mvc.setViewName("viewusers");
        
        //return new ModelAndView("viewusers","list",list);  
        return mvc;
    }  
    
    @RequestMapping(value = "/payment/", method = RequestMethod.GET)
    public ResponseEntity<List<Payment>> listAllPayments() {
        List<Payment> payments = dao5.getAllPayment();
        if(payments.isEmpty()){
            return new ResponseEntity<List<Payment>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<Payment>>(payments, HttpStatus.OK);
    }
    
    @RequestMapping("/payment")  
    public ModelAndView payment(@ModelAttribute("er") EventRegister er){  
                  
        return new ModelAndView("payment","command",er);  
    }  
    @RequestMapping("/payment/{id}")  
    public ModelAndView payment(@PathVariable("id") int id){  
                  
        return new ModelAndView("payment","id",id);  
    } 
    @RequestMapping("/viewpayment")  
    public ModelAndView viewpayment(Principal p){  
        ModelAndView mvc=new ModelAndView();
        String name=p.getName();
        mvc.addObject("uname", name);
        mvc.setViewName("viewpayment");
        return mvc; 
    } 
            
    @RequestMapping("/vieweventregister")  
    public ModelAndView vieweventregister(Principal p){  
        ModelAndView mvc=new ModelAndView();
        String name=p.getName();
        mvc.addObject("uname", name);
        mvc.setViewName("vieweventregister");        
        return mvc;  
    } 
        
    @RequestMapping("/profile")  
    public ModelAndView payment(Principal p,@ModelAttribute("msg") MessageRegister msg){  
           ModelAndView mvc=new ModelAndView();
           Register r=dao2.getEmpById(p.getName());//
           
           if(r.getUser_role_id()==2){
               mvc.setViewName("profile");
               mvc.addObject("command", r);
               mvc.addObject("uname", p.getName());
               mvc.addObject("msg", msg.getMessage());
               mvc.addObject("role", "ROLE_USER");                                             
           }
           else{
               if(r.getUser_role_id()==1){
                    
                    mvc.setViewName("redirect:/adminprofile");
                    
                }
           }
           
           
        return mvc;  
    }  
    
    @RequestMapping("/adminprofile")  
    public ModelAndView adminpage(Principal p){ 
         ModelAndView mvc=new ModelAndView();
           Register r=dao2.getEmpById(p.getName());//
           if(r.getUser_role_id()==1){
                    
                    mvc.setViewName("adminprofile");
                    mvc.addObject("command", r);
                    mvc.addObject("uname", p.getName());
                    mvc.addObject("role", "ROLE_ADMIN");
            }else{
                    mvc.setViewName("http://localhost:8080/EventScheduler/");
                    
            }
           
        return mvc;  
    }
    
    @RequestMapping("/myevent")  
    public ModelAndView myeventhistory(Principal p){  
           ModelAndView mvc=new ModelAndView("myevent");
           List<EventRegister> list=dao4.getEvtByEmailId(p.getName());
           mvc.addObject("list", list);
           mvc.addObject("uname", p.getName());
        return mvc;  
    } 
    
    @RequestMapping("/mypayhistory")  
    public ModelAndView mypayhistory(Principal p){  
           ModelAndView mvc=new ModelAndView("mypayhistory");
           List<PaymentEventRegister> list=dao4.getEvtMyPayHistoryByEmailId(p.getName());
           mvc.addObject("list", list);
           mvc.addObject("uname", p.getName());
        return mvc;  
    }  
     @RequestMapping("/myCartItem")  
    public ModelAndView myCartItem(Principal p){  
           ModelAndView mvc=new ModelAndView("myCartItem");
           List<PaymentEventRegister> list=dao4.getEvtMyCartItemByEmailId(p.getName());
           mvc.addObject("list", list);
           mvc.addObject("uname", p.getName());
           System.gc();
                   
        return mvc;  
    } 
    
    
    
    /* It displays object data into form for the given id.  
     * The @PathVariable puts URL data into variable.*/
    @RequestMapping(value="/editcandidate/{email}")  
    public ModelAndView edit(@PathVariable String email){  
                
        ModelAndView mvc=new ModelAndView();                
        mvc.addObject("email", email);        
        mvc.setViewName("redirect:/candidateedit");        

        return mvc;  
    }       
    
    @RequestMapping(value="/candidateedit")  
    public ModelAndView canedit(@ModelAttribute("email") String email,Principal p){          
        
        Register r=dao2.getEmpById(email);  
        ModelAndView mvc=new ModelAndView();
        String name=p.getName();
        mvc.addObject("uname", name);        
        mvc.addObject("command", r);
        
        mvc.setViewName("candidateeditform");        
        
        return mvc;  
    }   
    
    /* It updates model object. */
    @RequestMapping(value="/editsavecandidate",method = RequestMethod.POST)  
    public ModelAndView editsave(@ModelAttribute("r") Register r){  
        dao2.update(r);  
        return new ModelAndView("redirect:/viewusers");  
    }  
    /* It deletes record for the given id in URL and redirects to /viewusers */  
    @RequestMapping(value="/deletecandidate/{email}/",method = RequestMethod.GET)  
    public ModelAndView delete(@PathVariable String email){                          
        
        dao2.delete(email);                 
        return new ModelAndView("redirect:/viewusers");  
    } 

    /* It deletes record for the given id in URL and redirects to /viewusers */  
    @RequestMapping(value="/candidate/{id}",method = RequestMethod.GET)  
    public ModelAndView register(@PathVariable String id){  
        String eid=id;
       // ModelAndView mvc=new ModelAndView("candidate");
        //mvc.addObject("e_id", e_id);
        //return mvc;  
        return new ModelAndView("candidate","eid",eid);
    } 
}
