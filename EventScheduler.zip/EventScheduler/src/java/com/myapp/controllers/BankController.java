/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myapp.controllers;

import java.security.Principal;
import com.myapp.beans.Bank;
import com.myapp.beans.Event;
import com.myapp.beans.EventRegister;
import com.myapp.beans.Payment;
import com.myapp.dao.BankDao;
import com.myapp.dao.EventRegisterDao;
import com.myapp.dao.PaymentDao;
import com.myapp.mail.MailGateway;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping(value = "/")
public class BankController {
        
    @Autowired            
    BankDao dao3;//will inject dao3 from xml file    
    
    @Autowired
    EventRegisterDao dao4;//will inject dao4 from xml file 
    
    @Autowired
    PaymentDao dao5;//will inject dao5 from xml file    
      
    /* It provides list of employees in model object */  
    @RequestMapping("/viewbalance")  
    public ModelAndView viewevent(){  
        List<Bank> list=dao3.getBankAccountDetails();          
        return new ModelAndView("viewbalance","list",list);  
    }          
    /* It displays object data into form for the given id.  
     * The @PathVariable puts URL data into variable.*/
    @RequestMapping(value="/checkpoint",method = RequestMethod.POST)  
    public ModelAndView edit(@ModelAttribute("b") Bank b,@ModelAttribute("p") Payment p){  
        ModelAndView mvc=new ModelAndView("onetimepasswordform");
        try{
          dao3.getEmpById(b.getCard_num(),b.getExpirydate(),b.getCvc());        
          mvc.addObject("message", "Checkpoint Verified");
          mvc.addObject("p_id", p.getP_id());
          mvc.addObject("command", b);
          
          return mvc;         
        }catch(Exception e){        
          mvc.addObject("message", e.getMessage());
          return mvc;
        }        
    }           
    @RequestMapping(value="/checkpointotp",method = RequestMethod.POST)  
    public ModelAndView otp(@ModelAttribute("b") Bank b,@ModelAttribute("py") Payment py,Principal p){          
        try{
          ModelAndView mvc=new ModelAndView("redirect:/profile");
          dao3.getEmpOTP(b.getCard_num(),b.getOtp());          
          
          System.out.println(p.getName());
          

            

            //Real insert(email)
            //EventRegister r=dao4.getEvtByEmailAndEventId(p.getName(), er.getE_id());
                              
//          dao5.savePayment(r.getC_id(), 200, "yes");
            dao5.updatePayment(py.getP_id(), 200, "yes");
          
          mvc.addObject("message", "Payment Paid Successfully"); 
          
          //mvc.addObject("command", b);
          return mvc;         
        }catch(Exception e){        
          ModelAndView mvc=new ModelAndView("onetimepasswordform");
          mvc.addObject("card_num", b.getCard_num());
          mvc.addObject("p_id", py.getP_id());
          mvc.addObject("command", b);
          mvc.addObject("message", e.getMessage()+"Incorrect OTP Code try Again!... ");
          return mvc;
        }        
    }           
    /* It updates model object. */
    @RequestMapping(value="/checkpointbalance",method = RequestMethod.POST)  
    public ModelAndView editsave(@ModelAttribute("b") Bank b){  
        dao3.update(b);  
        return new ModelAndView("redirect:/viewbalance");  
    }  
    
    
}

