
package com.myapp.beans;

public class Payment {
    
    private int p_id;
    private int c_id;
    
    private int paid_fees;
    private String paid_status;
    

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public int getC_id() {
        return c_id;
    }

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    
    public int getPaid_fees() {
        return paid_fees;
    }

    public void setPaid_fees(int paid_fees) {
        this.paid_fees = paid_fees;
    }

    public String getPaid_status() {
        return paid_status;
    }

    public void setPaid_status(String paid_status) {
        this.paid_status = paid_status;
    }
    
    
    
    
    
}
