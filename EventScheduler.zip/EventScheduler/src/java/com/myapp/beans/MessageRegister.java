
package com.myapp.beans;

public class MessageRegister {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    
    
    
            
            
}
