
package com.myapp.dao;


import com.myapp.beans.Payment;
import com.myapp.beans.Register;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class PaymentDao {
            
    JdbcTemplate template;
    
    public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
    } 
    
       
    
    public Payment getPaymentId(int c_id){          
        
        String sql="select * from Payment where c_id=?";  
        return template.queryForObject(sql, new Object[]{c_id},new BeanPropertyRowMapper<Payment>(Payment.class));               
        
    }  
     
    public int savePayment(int c_id,int paid_fees,String paid_status){
       String sql="insert into Payment( c_id, paid_fees, paid_status) values("+ c_id +"," +paid_fees+ ",'" +paid_status+ "')";              
        return template.update(sql);
    }
    public int updatePayment(int p_id,int paid_fees,String paid_status){
       String sql="update Payment set paid_fees = " +paid_fees+ ", paid_status ='" +paid_status+ "' where p_id=" + p_id + "";              
        return template.update(sql);
    }
    
    @RequestMapping("/getAllPayment")
    public List<Payment> getAllPayment(){  
        return template.query("select * from Payment",new RowMapper<Payment>(){  
            public Payment mapRow(ResultSet rs, int row) throws SQLException {                  
                 Payment p=new Payment();  
                 p.setP_id(rs.getInt(1));
                 p.setC_id(rs.getInt(2));
                 p.setPaid_fees(rs.getInt(3));
                 p.setPaid_status(rs.getString(4));
                 
                 
            return p;  
            }  
        });  
    }  
                          
}