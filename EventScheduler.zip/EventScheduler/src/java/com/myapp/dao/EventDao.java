
package com.myapp.dao;


import com.myapp.beans.Event;
import java.sql.ResultSet;
import java.sql.SQLException;


import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class EventDao {
    
    JdbcTemplate template;
    
    public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
    } 
    
    public int save(Event p){
       String sql="insert into Event( name, date, organized_by, incharge, fees) values('"+ p.getName() +"','"+ p.getDate() +"','"+ p.getOrganized_by() +"', '"+ p.getIncharge() +"', "+ p.getFees() +")";       
       
        return template.update(sql);
    }
    public int update(Event p){        
        String sql="update Event set name='"+p.getName()+"', date='"+p.getDate()+"', organized_by='"+p.getOrganized_by()+"', incharge='"+p.getIncharge()+"', fees="+p.getFees()+" where e_id="+p.getE_id()+"";  
        return template.update(sql);
    }
    
    public int delete(int id){  
        String sql="delete from Event where e_id="+id+"";  
        return template.update(sql);  
    }  
    public Event getEmpById(int id){          
         String sql="select * from Event where e_id=?";  
    return template.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Event>(Event.class));
    }  
    
    @RequestMapping("/getAllEventRegisterNews")
    public List<Event> getAllEventRegisterNews(){  
        return template.query("select e_id,name,date from Event",new RowMapper<Event>(){  
            public Event mapRow(ResultSet rs, int row) throws SQLException {  
                
                 Event er=new Event();  
                 er.setE_id(rs.getInt(1));                                                  
                 er.setName(rs.getString(2));
                 er.setDate(rs.getString(3));
                 
            return er;  
            }  
        });  
    }
    
    
    @RequestMapping("/getAllEvent")
    public List<Event> getAllEvent(){  
        return template.query("select * from Event",new RowMapper<Event>(){  
            public Event mapRow(ResultSet rs, int row) throws SQLException {  
                
                 Event e=new Event();  
                 e.setE_id(rs.getInt(1));
                 e.setName(rs.getString(2));
                 e.setDate(rs.getString(3));
                 e.setOrganized_by(rs.getString(4));
                 e.setIncharge(rs.getString(5));
                 e.setFees(rs.getFloat(6));                             
                 e.setStatus(rs.getString(7)); 
                return e;                                          
            }  
        });  
    }  
    
}
