
package com.myapp.dao;

import com.myapp.beans.MessageRegister;
import com.myapp.beans.Register;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.sql.SQLException;
/**
 *
 * @author Mayan
 */
@RestController
@RequestMapping("/")
public class RegisterDao {
    
    JdbcTemplate template;
    
    public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
    } 
    
    public int save(Register r){
       String sql="insert into Register( e_id, name, lastname, gender, college_name, email, pwd) values("+ r.getE_id() +",'"+ r.getName() +"','"+ r.getLastname() +"','"+ r.getGender()+"', '"+ r.getCollege_name() +"', '"+ r.getEmail() +"', '" +r.getPwd()+ "')";       
       
        return template.update(sql);
    }
    public int update(Register r){        
        String sql="update Register set e_id="+r.getE_id()+", name='"+r.getName()+"', lastname='"+r.getLastname()+"', gender='"+r.getGender()+"', college_name='"+r.getCollege_name()+"', email='"+r.getEmail()+"', pwd='"+r.getPwd()+"' where email='"+r.getEmail()+"'";  
        return template.update(sql);
    }
    
    public int delete(String email){  
        String sql="delete from Register where email='"+email+"'";  
        return template.update(sql);  
    }  
    public Register getEmpById(String email){          
         String sql="select * from Register where email=?";  
         return template.queryForObject(sql, new Object[]{email},new BeanPropertyRowMapper<Register>(Register.class));
    }  
    public Integer getEmpEmail(String email){ 
        
         String sql="select e_id from Register where email=?";  
         int h;
         try{           
              template.queryForInt(sql, new Object[]{email});
              h=1;
         }catch(Exception e){
             
             System.out.println(e.getMessage());
              h=0;
         }

                 return h;         
    }
        
    @RequestMapping("/getAllUser")
    public List<Register> getAllUser(){  
        return template.query("select * from Register",new RowMapper<Register>(){  
            public Register mapRow(ResultSet rs, int row) throws SQLException {  
                
                 Register e=new Register();  
                 e.setE_id(rs.getInt(1));
                 e.setName(rs.getString(2));
                 e.setLastname(rs.getString(3));
                 e.setGender(rs.getString(4));
                 e.setCollege_name(rs.getString(5));
                 e.setEmail(rs.getString(6));
                 e.setPwd(rs.getString(7));                 
                 e.setActive(rs.getString(8)); 
                 e.setUser_role_id(rs.getInt(9));  
            return e;  
            }  
        });  
    }  
    
}
