
package com.myapp.dao;

import com.myapp.beans.EventRegister;
import com.myapp.beans.PaymentEventRegister;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class EventRegisterDao {

    JdbcTemplate template;
    
    public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
    } 
    
    public int save(EventRegister er){
       String sql="insert into Event_Register(e_id, email) values("+ er.getE_id() +",'"+ er.getEmail() +"')";       
       
        return template.update(sql);
    }
    public int altsave(int eid,String email){
       String sql="insert into Event_Register(e_id, email) values("+ eid +",'"+ email +"')";       
       
        return template.update(sql);
    }
    public int update(EventRegister er){        
        String sql="update Event_Register set email='"+er.getEmail()+"' where email='"+er.getEmail()+"'";  
        return template.update(sql);
    }
    
    public int delete(int c_id){  
        String sql="delete from Event_Register where c_id="+c_id+"";  
        return template.update(sql);  
    } 
    
    public EventRegister getEmpById(String email){          
         String sql="select * from Event_Register where email=?";  
         return template.queryForObject(sql, new Object[]{email},new BeanPropertyRowMapper<EventRegister>(EventRegister.class));
    }
    public List<EventRegister> getEvtByEmailId(String email){          
                           
                           
         return template.query("select * from Event_Register where email=?",new Object[]{email},new RowMapper<EventRegister>(){  
            public EventRegister mapRow(ResultSet rs, int row) throws SQLException {  
                
                 EventRegister er=new EventRegister();  
                 er.setE_id(rs.getInt(1));
                 er.setC_id(rs.getInt(2));                
                 er.setEmail(rs.getString(3));
                 
            return er;  
            }  
        });    
    }
    
    public List<PaymentEventRegister> getEvtMyPayHistoryByEmailId(String email){       
        String sql="SELECT p.p_id, p.c_id, p.paid_fees, p.paid_status,er.e_id,er.email FROM payment p,event_register er where p.c_id=er.c_id and er.email=? and p.paid_status='yes'";
                          
         return template.query(sql,new Object[]{email},new RowMapper<PaymentEventRegister>(){  
            public PaymentEventRegister mapRow(ResultSet rs, int row) throws SQLException {  
                
                 PaymentEventRegister pvt=new PaymentEventRegister();  
                 pvt.setP_id(rs.getInt(1));
                 pvt.setC_id(rs.getInt(2));   
                 pvt.setPaid_fees(rs.getInt(3)); 
                 pvt.setPaid_status(rs.getString(4)); 
                 pvt.setE_id(rs.getInt(5));
                 pvt.setEmail(rs.getString(6));
                 
            return pvt;  
            }  
        });    
    }
    
    public List<PaymentEventRegister> getEvtMyCartItemByEmailId(String email){       
        String sql="SELECT p.p_id, p.c_id, p.paid_fees, p.paid_status,er.e_id,er.email FROM payment p,event_register er where p.c_id=er.c_id and er.email=? and p.paid_status='no'";
                                                                                 
         return template.query(sql,new Object[]{email},new RowMapper<PaymentEventRegister>(){  
            public PaymentEventRegister mapRow(ResultSet rs, int row) throws SQLException {  
                
                 PaymentEventRegister pvt=new PaymentEventRegister();  
                 pvt.setP_id(rs.getInt(1));
                 pvt.setC_id(rs.getInt(2));   
                 pvt.setPaid_fees(rs.getInt(3)); 
                 pvt.setPaid_status(rs.getString(4)); 
                 pvt.setE_id(rs.getInt(5));
                 pvt.setEmail(rs.getString(6));
                 
            return pvt;  
            }  
        });    
    }
    
    
    
    
    
    public Integer getEvtByEmailAndEventId(String email,int e_id){          
         String sql="select c_id from Event_Register where email=? and e_id=?";  
         try{
         return template.queryForInt(sql, new Object[]{email,e_id});
         }catch(Exception e){
         return 0;    
         }
         
    } 
    
        
    @RequestMapping("/getAllEventRegister")
    public List<EventRegister> getAllEventRegister(){  
        return template.query("select * from Event_Register",new RowMapper<EventRegister>(){  
            public EventRegister mapRow(ResultSet rs, int row) throws SQLException {  
                
                 EventRegister er=new EventRegister();  
                 er.setE_id(rs.getInt(1));
                 er.setC_id(rs.getInt(2));                
                 er.setEmail(rs.getString(3));
                 
            return er;  
            }  
        });  
    }
    
}
