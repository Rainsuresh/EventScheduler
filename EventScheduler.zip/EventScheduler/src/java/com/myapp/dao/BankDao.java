
package com.myapp.dao;

import com.myapp.beans.Bank;
import com.myapp.beans.Payment;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author Mayan
 */
public class BankDao {
    
      JdbcTemplate template;
    
    public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
    } 

    public int update(Bank b){        
        String sql="update Event set balance="+b.getBalance()+" where card_num="+b.getCard_num()+"";  
        return template.update(sql);
    }
    
    public Bank getEmpById(int id,String expiry,int cvc){          
         
        /*String sql="select * from Bank where card_num="+id+" and expirydate='"+expiry+"' and cvc="+cvc+"";  
        return template.queryForObject(sql, new Object[]{},new BeanPropertyRowMapper<Bank>(Bank.class));
        */
        String sql="select * from Bank where card_num=? and expirydate=? and cvc=?";  
        return template.queryForObject(sql, new Object[]{id,expiry,cvc},new BeanPropertyRowMapper<Bank>(Bank.class));
        
    }  
     public Bank getEmpOTP(int id,int cvc){          
         
        /*String sql="select * from Bank where card_num="+id+" and expirydate='"+expiry+"' and cvc="+cvc+"";  
        return template.queryForObject(sql, new Object[]{},new BeanPropertyRowMapper<Bank>(Bank.class));
        */
        String sql="select * from Bank where card_num=? and otp=?";  
        return template.queryForObject(sql, new Object[]{id,cvc},new BeanPropertyRowMapper<Bank>(Bank.class));
        
    }  

    public int savePayment(int c_id,int paid_fees,String paid_status){
       String sql="insert into Payment( c_id, paid_fees, paid_status) values("+ c_id +"," +paid_fees+ ",'" +paid_status+ "')";              
        return template.update(sql);
    } 
    
    public List<Bank> getBankAccountDetails(){  
        return template.query("select * from Bank",new RowMapper<Bank>(){  
            public Bank mapRow(ResultSet rs, int row) throws SQLException {                  
                 Bank b=new Bank();  
                 b.setAcc_number(rs.getInt(1));
                 b.setCust_id(rs.getInt(2));
                 b.setPwd(rs.getString(3));
                 b.setBalance(rs.getInt(4));
                 b.setCard_num(rs.getInt(5));
                 b.setExpirydate(rs.getString(6));
                 b.setCvc(rs.getInt(7));                             
            return b;  
            }  
        });  
    }  
}
